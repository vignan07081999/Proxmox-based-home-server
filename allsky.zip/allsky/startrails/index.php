<?php
$dir = ".";
$prefix = "startrails";
$title = "Startrails";
include_once("../show_thumbnails.php");
?>
