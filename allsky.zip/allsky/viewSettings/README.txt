This directory holds settings-related files from the Pi so they can optionally be displayed in the Allsky Website.
